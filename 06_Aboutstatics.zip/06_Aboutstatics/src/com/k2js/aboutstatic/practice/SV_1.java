package com.k2js.aboutstatic.practice;

class Sv_1{
	static int i=10;
	public static void main(String...abc){
		System.out.println(Sv_1.i);
	}
}