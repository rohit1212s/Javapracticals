// For checking default value of int data type

package com.k2js.aboutstatic.practice;

class Sv_2{
	static int i;
	public static void main(String...abc){
			System.out.println(i);
	}

}