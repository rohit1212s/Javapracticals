// checking the difference between static int i and static int i=0

package com.k2js.aboutstatic.practice;

class STD3{
	static int i;
}

class STD4{
	static int i=0;
}