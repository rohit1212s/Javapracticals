// To check final static value --way 3

package com.k2js.aboutstatic.practice;

class FSTB3{
	final static int i;
	static int j=i=30;
}