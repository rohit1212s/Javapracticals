// To check final static value --way 1

package com.k2js.aboutstatic.practice;

class FSTB{
	final static int i=10;
}