// To check final static value --way 2

package com.k2js.aboutstatic.practice;

class FSTB2{
	final static int i;
	static{
		i=20;
	}
}